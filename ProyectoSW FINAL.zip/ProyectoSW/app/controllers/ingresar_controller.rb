class IngresarController < ApplicationController
  def ingreso
  	@usuarios = Ingreso.count
    @limite = 200
    @resultado = @limite - @usuarios
    puts @resultado
  end
end
