class SeguridadController < ApplicationController
  def vistaseguridad
  end
end
