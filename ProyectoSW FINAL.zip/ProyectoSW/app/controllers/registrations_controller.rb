class RegistrationsController < Devise::sessionsController
	def new
		super
	end
		
	protected

	 	def after_sign_in_path_for(resource)
	   		 '../vehiculos/index/'  Or :vehiculos#index
	  	end
	end
end
