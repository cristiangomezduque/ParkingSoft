class GuardasController < ApplicationController
  before_action :set_guarda, only: [:show, :edit, :update, :destroy]

  # GET /guardas
  # GET /guardas.json
  def index
    @guardas = Guarda.all
  end

  # GET /guardas/1
  # GET /guardas/1.json
  def show
  end

  # GET /guardas/new
  def new
    @guarda = Guarda.new
  end

  # GET /guardas/1/edit
  def edit
  end

  # POST /guardas
  # POST /guardas.json
  def create
    @guarda = Guarda.new(guarda_params)

    respond_to do |format|
      if @guarda.save
        format.html { redirect_to @guarda, notice: 'Guarda was successfully created.' }
        format.json { render :show, status: :created, location: @guarda }
      else
        format.html { render :new }
        format.json { render json: @guarda.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /guardas/1
  # PATCH/PUT /guardas/1.json
  def update
    respond_to do |format|
      if @guarda.update(guarda_params)
        format.html { redirect_to @guarda, notice: 'Guarda was successfully updated.' }
        format.json { render :show, status: :ok, location: @guarda }
      else
        format.html { render :edit }
        format.json { render json: @guarda.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /guardas/1
  # DELETE /guardas/1.json
  def destroy
    @guarda.destroy
    respond_to do |format|
      format.html { redirect_to guardas_url, notice: 'Guarda was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_guarda
      @guarda = Guarda.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def guarda_params
      params.require(:guarda).permit(:codigo, :cedula, :nombre, :apellido, :turno, :fecha)
    end
end
