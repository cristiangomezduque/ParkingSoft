class InfoVController < ApplicationController
  def infoVehiculo
  	
  end
end
