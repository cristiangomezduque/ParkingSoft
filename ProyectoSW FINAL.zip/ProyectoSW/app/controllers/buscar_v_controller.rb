class BuscarVController < ApplicationController
  def buscarVehiculo
  	@buscar = Vehiculo.find_by placa: params[:busqueda]
    if @buscar != nil
      puts @buscar.placa
      puts 'lo encontre'
      #redirect_to "localhost:3000/usuarios/infoUsuario"
      render "infoVehiculo"
    end  
  end
end
