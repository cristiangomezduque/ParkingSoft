class VistaController < ApplicationController
  def index
  end
end
