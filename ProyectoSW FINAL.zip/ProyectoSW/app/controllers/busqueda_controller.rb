class BusquedaController < ApplicationController
  def buscar
  	@busqueda = Usuario.all
  end
end
