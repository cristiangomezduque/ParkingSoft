class Turno < ActiveRecord::Base

end
