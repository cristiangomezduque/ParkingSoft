class Usuario < ActiveRecord::Base
  
  has_many :vehiculo
  validates :cedula, :presence =>
      {:message => ": debe ingresar una cedula"}, length: {minimum: 7, :message => ": debe tener entre 7 y 10 caracteres"}, uniqueness:true

   validates :nombre, :presence => { :message => ": debe ingresar un nombre"}   
   validates :apellido, :presence => { :message => ": debe ingresar un apellido"}

end
