class Guarda < ActiveRecord::Base
end
