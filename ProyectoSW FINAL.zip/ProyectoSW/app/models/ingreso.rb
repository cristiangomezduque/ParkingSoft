class Ingreso < ActiveRecord::Base
end
