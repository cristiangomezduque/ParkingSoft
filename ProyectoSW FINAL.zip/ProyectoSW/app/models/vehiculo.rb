class Vehiculo < ActiveRecord::Base
  belongs_to :usuario
  validates :placa, :presence =>
      {:message => ": debe ingresar una placa"}, length: {minimum: 4, maximum: 6, :message => "debe tener entre 5 y 6 caracteres"}, uniqueness: {case_sensitive: false, message: ": Esta placa ya existe"}

  validates :modelo, :presence => { :message => ": debe ingresar un modelo"}
  validates :marca, :presence => { :message => ": debe ingresar la marca del vehiculo"}
  validates :color, :presence => { :message => ": debe ingresar el color del vehiculo"}    
  validates :propietario, :presence => { :message => ": debe ingresar el propietario del vehiculo"}
end
