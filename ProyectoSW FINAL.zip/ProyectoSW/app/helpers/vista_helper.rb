module VistaHelper
end
