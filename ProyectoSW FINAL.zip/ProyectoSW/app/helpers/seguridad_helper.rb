module SeguridadHelper
end
