require 'test_helper'

class SeguridadControllerTest < ActionController::TestCase
  test "should get vistaseguridad" do
    get :vistaseguridad
    assert_response :success
  end

end
