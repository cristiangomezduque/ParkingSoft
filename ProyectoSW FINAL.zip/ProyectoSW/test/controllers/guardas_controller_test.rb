require 'test_helper'

class GuardasControllerTest < ActionController::TestCase
  setup do
    @guarda = guardas(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:guardas)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create guarda" do
    assert_difference('Guarda.count') do
      post :create, guarda: { apellido: @guarda.apellido, cedula: @guarda.cedula, codigo: @guarda.codigo, fecha: @guarda.fecha, nombre: @guarda.nombre, turno: @guarda.turno }
    end

    assert_redirected_to guarda_path(assigns(:guarda))
  end

  test "should show guarda" do
    get :show, id: @guarda
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @guarda
    assert_response :success
  end

  test "should update guarda" do
    patch :update, id: @guarda, guarda: { apellido: @guarda.apellido, cedula: @guarda.cedula, codigo: @guarda.codigo, fecha: @guarda.fecha, nombre: @guarda.nombre, turno: @guarda.turno }
    assert_redirected_to guarda_path(assigns(:guarda))
  end

  test "should destroy guarda" do
    assert_difference('Guarda.count', -1) do
      delete :destroy, id: @guarda
    end

    assert_redirected_to guardas_path
  end
end
