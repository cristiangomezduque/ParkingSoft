require 'test_helper'

class BuscarVControllerTest < ActionController::TestCase
  test "should get buscarVehiculo" do
    get :buscarVehiculo
    assert_response :success
  end

end
