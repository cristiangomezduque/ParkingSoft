require 'test_helper'

class InfoVControllerTest < ActionController::TestCase
  test "should get infoVehiculo" do
    get :infoVehiculo
    assert_response :success
  end

end
