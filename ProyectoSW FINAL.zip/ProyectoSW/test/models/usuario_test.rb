require 'test_helper'

class UsuarioTest < ActiveSupport::TestCase

  test "guardar_usuario" do
    user1 = Usuario.new({ cedula: '10476824', nombre: 'Roberto', apellido:'rojas', ocupacion: 'Estudiante'})
    assert user1.save
  end

  test "buscar_usuario" do
    puts "prueba para buscar un usuario "
    buscar = Usuario.find_by nombre: 'juan camilo'
    if buscar == nil
      #puts "usuario no existe"
      assert false
    end
    puts buscar.inspect
    assert true
  end 
  

end
