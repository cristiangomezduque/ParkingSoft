require 'test_helper'

class GuardaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
