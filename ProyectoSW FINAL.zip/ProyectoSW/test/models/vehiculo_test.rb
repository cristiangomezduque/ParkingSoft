require 'test_helper'

class VehiculoTest < ActiveSupport::TestCase
#   test "the truth" do
#     assert true
#   end
end
