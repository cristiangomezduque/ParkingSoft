class CreateGuardas < ActiveRecord::Migration
  def change
    create_table :guardas do |t|
      t.string :codigo
      t.string :cedula
      t.string :nombre
      t.string :apellido
      t.string :turno
      t.date :fecha

      t.timestamps null: false
    end
  end
end
