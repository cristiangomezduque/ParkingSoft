class CreateIngresos < ActiveRecord::Migration
  def change
    create_table :ingresos do |t|
      t.string :vehiculo

      t.timestamps null: false
    end
  end
end
