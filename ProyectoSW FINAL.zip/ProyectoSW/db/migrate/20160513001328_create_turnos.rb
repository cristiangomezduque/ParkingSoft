class CreateTurnos < ActiveRecord::Migration
  def change
    create_table :turnos do |t|
      t.string :cedula
      t.string :lugar
      t.date :fecha

      t.timestamps null: false
    end
  end
end
