class CreateVehiculos < ActiveRecord::Migration
  def change
    create_table :vehiculos do |t|
      t.string :placa
      t.string :tipo
      t.string :modelo
      t.string :marca
      t.string :color
      t.string :propietario

      t.timestamps null: false
    end
  end
end
